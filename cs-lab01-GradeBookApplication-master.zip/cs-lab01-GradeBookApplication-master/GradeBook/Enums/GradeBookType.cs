﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GradeBook.Enums
{
    public enum GradeBookType
    {
        Standard,
        Ranked,
        ESNU, 
        OneToFour, 
        SixPoint
    }
}
